$(document).ready(function(){

/*! Fades in page on load */

$('body').fadeIn(5000);

});